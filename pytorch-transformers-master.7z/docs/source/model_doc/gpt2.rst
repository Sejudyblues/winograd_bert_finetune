OpenAI GPT2
----------------------------------------------------

``GPT2Config``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.GPT2Config
    :members:


``GPT2Tokenizer``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.GPT2Tokenizer
    :members:


``GPT2Model``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.GPT2Model
    :members:


``GPT2LMHeadModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.GPT2LMHeadModel
    :members:


``GPT2DoubleHeadsModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.GPT2DoubleHeadsModel
    :members:
